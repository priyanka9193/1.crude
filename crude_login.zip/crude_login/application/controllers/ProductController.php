<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ProductController extends CI_Controller {

	public function __construct(){

	        parent::__construct();
	  	 	$this->load->model('ProductModel');
	  	 	date_default_timezone_set('Asia/Kolkata');
	}
	public function index()
	{
		$data['product']=$this->ProductModel->getdata('tbl_product');
		$this->load->view('ProductView',$data);
	}
	public function Add()      
	{
        $this->load->view('AddProductView');
	}
    public function insert() {
    $logo = trim($this->uploadFile('logo'));
    $img = trim($this->uploadFile('img'));
    echo "File Name : ".$logo;
    if(strlen($logo)>0 && strlen($img)>0) {
        $data = array('name' => $this->input->post('name'),
                      'description' => $this->input->post('description'),
                      'img'=>$img,
                      'logo'=>$logo,
                      'createdAt  '=>date('Y-m-d H:i:s')
                   );
        $result = $this->ProductModel->insert('tbl_product',$data);
        if(!$result==0){                
            return redirect("ProductController");    
        } else {
            echo "Fail";
        }
        } else {
            echo "Unable to upload file";
        }   
    }   
	public function delete()
        {
            $id =$this->input->post('id');
            $data=$this->ProductModel->delete('tbl_product',$id);            
            if ($data==1)
            {
                echo "Your record has been deleted!";                
            }
            else
            {
                echo "Deleted Fail..";
            }
        }   
    public function load($id)
    {
        $data['product'] = $this->ProductModel->load('tbl_product',$id);
        $this->load->view('AddProductView',$data);

     }
        public function update() {
        $id = $this->input->post('id');
        $data['product'] = $this->ProductModel->load('tbl_product',$id);
        $logo = trim($this->uploadFile('logo'));
        $img = trim($this->uploadFile('img'));
        if(empty($logo)){
            $logo=$data['product'][0]['logo'];
        }
         if(empty($img)){
            $img=$data['product'][0]['img'];
        }

         $data = array('name' => $this->input->post('name'),
                      'description' => $this->input->post('description'),
                      'img'=>$img,
                      'logo'=>$logo
                   );
            $result = $this->ProductModel->update('tbl_product', $data, $id);
            if($result==1){
                 return redirect("ProductController");  
            } else {
                echo "Fail";
            }
    }
    public function uploadFile($fileName) {
        $upload_path='./assets/uploads/'; 
        $config = array(
        'upload_path' => $upload_path,
        'allowed_types' => "gif|jpg|png|jpeg"
        //'overwrite' => TRUE
        /*'max_size' => "2048000", 
        'max_height' => "768",
        'max_width' => "1024"*/
        );
        $this->load->library('upload', $config);
        if(!$this->upload->do_upload($fileName)) {
            return "";
            //echo "Fail : ".$this->upload->display_errors();
            //$data['imageError'] =  $this->upload->display_errors();
        } else {
            $uploadData = $this->upload->data();
            $fileName =  $uploadData['file_name'];
            //$ext = explode('.',$file_name);
            //$fileName = time().".".$ext[1];
            return $fileName;
        }     
        }

}
?>