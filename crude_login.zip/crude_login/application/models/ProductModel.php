<?php 
if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class ProductModel extends CI_Model{
  
   
    public function getdata($tableName)
    {      
        $query=$this->db->get($tableName);
        return $query->result_array();
    }
    public function insert($tblName, $data) {      
        
        $this->db->insert($tblName, $data);
        return $this->db->insert_id();
    }
    public function delete($tblName, $id) {
        $this->db-> where('id', $id);
        return $this->db->delete($tblName);
    }
    public function update($tblName, $data, $id) {
        $this->db->where('id', $id);
        return $this->db->update($tblName, $data);  
    }
    public function load($tableName,$id)
    {
        $this->db->where('id',$id);
        $result=$this->db->get($tableName);
        return $result->result_array();
    }
}