<?php 
include('layouts/header.php');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Master
        <small>Product </small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-briefcase"></i> Master </a></li>
        <li><a href="#"> Product</a></li>
      </ol>
    </section>
    <!-- Main content -->
    <section class="content">
      <div class="row">
        <div class="col-xs-12">
           <div class="box">
            <div class="box-header">
              <h3 class="box-title">Product Details</h3>
              <p align="right">
                <a href="<?php echo site_url('ProductController/Add');?>">
                <button type="submit" class="btn bg-primary margin"><i class="fa fa-plus"></i>  Add  </button></a>
              </p>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
               <table id="example1" class="table table-bordered table-striped">
                <thead>
                  <tr>
                    <th>Sr.No</th>
                    <th> Product Name </th>
                    <th> Description </th>
                    <th> Logo  </th>
                    <th> Description </th>                    
                    <th colspan="2">Action</th>
                  </tr>
                  <tr>
                    <th></th>
                    <th></th>
                    <th></th>
                    <th></th> 
                    <th></th>                   
                    <th>edit</th>
                    <th>delete</th>
                  </tr>
                </thead>
                <tbody>
                <?php
                $no=0;
                foreach ($product as $data) 
                  {
                   $no++; 
                ?>
                <tr>
                  <td><?php echo $no; ?></td>
                  <td><?php echo $data['name']; ?></td>
                  <td><?php echo $data['description']; ?></td>
                  <td> <img  style="height: 100px;width: 100px;" src="<?php echo base_url().'assets/uploads/'.$data['logo']; ?>" ></td>
                   <td> <img  style="height: 100px;width: 100px;" src="<?php echo base_url().'assets/uploads/'.$data['img']; ?>" ></td>                
                  <td>
                    <a href='<?php echo site_url("ProductController/load/".$data['id']); ?>'><b><small class="label label-warning"><i class="fa fa-edit"></i></small></b></a>
                  </td>
                  </td>
                   <td>
                    <a id="delete" 
                    onclick="deleted(<?php echo $data['id'];?>)" href='#'><b> <small class="label label-danger"><i class="fa fa-trash"></i></small></b></a>
                  </td> 
                
                </tr>
                <?php
              }
              ?>               
                </tbody>
                <tfoot>
                 <tr>
                    <th>Sr.No</th>
                    <th> Product Name </th>
                    <th> Description </th>
                    <th> Logo  </th>
                    <th> Description </th>                    
                    <th colspan="2">Action</th>
                  </tr>
                </tfoot>
              </table>
            </div>
            <!-- /.box-body -->
          </div>
          <!-- /.box -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>
<script>
function deleted(id)
{ 
  //alert(bloodGroupID);
swal({
  title: "Are you sure to delete?",
  text: "Once deleted, you will not be able to recover this!",
  icon: "warning",
  buttons: true,
  dangerMode: true,
})
.then((willDelete) => {
  if (willDelete) {
    $.ajax({
        url: "<?php echo site_url('ProductController/delete');?>",
        type: "post",
        data: {'id':id},
        success: function (response) {
         
          swal(response, {
            icon: "success",
          });
          var URL = "<?php echo site_url('ProductController');?>";
          setTimeout(function(){ window.location = URL; }, 1000);
        },
        error: function(jqXHR, textStatus, errorThrown) {
           console.log(textStatus, errorThrown);
        }
    });
    
  } else {
    swal("Your record is safe!");
  }
});
}
</script>
  <?php
include('layouts/footer.php');
?>
