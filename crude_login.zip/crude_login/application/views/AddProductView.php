<?php 
include('layouts/header.php');
?>
  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Master
        <small>Product</small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-briefcase"></i> Master </a></li>
        <li><a href="#">product </a></li>
      </ol>
    </section>
    <section class="content">
      <div class="row">
        <div class="col-md-12">
              <div class="box box-info">
                <div class="box-header">
                  <h3 class="box-title">
                    <?php 
                  if(isset($product))
                    {
                      echo 'Update';
                    }
                  else
                    {
                      echo 'Add';
                    }
                  ?>  Master
                    <small>Agent</small>
                  </h3><br /><br />
                 <form method="post" role="form" enctype="multipart/form-data" action="<?php
                if(isset($product))
                {
                  echo site_url('ProductController/update');
                }
                else
                {
                echo site_url('ProductController/insert');
                }
                ?>"> 
                   <input type="hidden" name="id" value="<?php
                    if(isset($product))
                      {
                        echo $product[0]['id'];
                      }
                    ?>"> 
                  <div class="col-md-4">
                     <label>Product Name</label>
                      <div class="input-group">
                        <span class="input-group-addon"><i class="fa fa-shopping-cart"></i></span>
                            <input type="text" name="name" class="form-control" placeholder="Enter Product name" value="<?php if(isset($product))
                        {
                          echo $product[0]['name']; 
                        }
                        ?>" required>
                      </div>
                  </div>
                  <div class="col-md-4">
                     <label>Logo</label>
                      <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-picture-o"></i></span>
                            <?php 
                              if(isset($product))
                              {
                               ?>
                                <input type="file" name="logo" class="form-control" value="<?php if(isset($product))
                                  {
                                    echo $product[0]['logo']; 
                                  }
                                  ?>">
                               <?php 
                              }else{
                                ?>
                                <input type="file" name="logo" class="form-control" value="<?php if(isset($product))
                                  {
                                    echo $product[0]['logo']; 
                                  }
                                  ?>" required>
                                <?php
                              }
                            ?>
                            
                      </div>
                  </div>
                  <div class="col-md-4">
                     <label>Image</label>

                      <div class="input-group">
                            <span class="input-group-addon"><i class="fa fa-picture-o"></i></span>
                            <?php 
                              if(isset($product))
                              {
                               ?>
                                <input type="file" name="img" class="form-control" value="<?php if(isset($product))
                                {
                                  echo $product[0]['img']; 
                                }
                                ?>">
                               <?php 
                              }else{
                                ?>
                                <input type="file" name="img" class="form-control" value="<?php if(isset($product))
                                {
                                  echo $product[0]['img']; 
                                }
                                ?>" required>
                                <?php
                              }
                            ?>
                            
                      </div>

                  </div><br /><br/><br /><br />
                   <div class="col-md-12">
                     <label>Description</label>
                     <div class="box box-info1">
                        <div class="box-header">                          
                            
                        </div>
                          <!-- /.box-header -->
                          <div class="box-body pad">
                            
                                  <textarea id="editor1" name="description" rows="10" cols="80" required>
                                     <?php if(isset($product))
                                      {
                                        echo $product[0]['description']; 
                                      }
                                      ?>
                                  </textarea>
                          
                          </div>
                      </div>
                  </div>
                </div>
                  <div class="checkbox">
                    <label>
                     
                    </label>
                  </div>
                  <div class="box-footer">
                    <button type="submit" class="btn bg-primary margin"><i class="fa fa-save"></i> 
                        <?php
                        if(isset($product))
                         { 
                          echo "Update";
                          }
                        else
                          {
                            echo "Save";
                          }
                        ?> </button>  
                    
                    <button type="submit" class="btn btn-danger margin"><i class="fa fa-ban"> </i><a href="<?php echo site_url('ProductController/');?>" style="color:white">Cancel</a> </button>
                </div>
              </form>
            </div>
    </section>
    </div>   
<?php
  include('layouts/footer.php');
?>
